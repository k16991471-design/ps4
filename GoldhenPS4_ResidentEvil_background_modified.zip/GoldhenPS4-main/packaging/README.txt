GoldHEN Local Host 1.0.7 - Windows 10/11 x64

ONLINE WEBSITE
https://patnawa.github.io/GoldhenPS4/g2all/
The path is case-sensitive: use GoldhenPS4 exactly as shown.

Version 1.0.7 syncs the bundled web loader with upstream GamerHack's current
build: jb.js hands the kernel stage to afterglow.js (APM use-after-free, its
own stage per firmware) and the site ships the real per-firmware patch blobs
1400.bin/1402.bin instead of reusing 1352.bin. Firmware 14.02 and 14.00 are now
served by measured upstream offsets rather than local aliases. 14.01 has no
afterglow stage yet and stops cleanly before touching the kernel. Offsets for
14.x come from upstream and are still unproven on this host's hardware.

Version 1.0.6 replaced the bundled GoldHEN payload with the v2.4b18.14 beta
and routed firmware 14.02.

Version 1.0.4 adds the 11.50 load path: the primitive releases its grooming
memory between retries instead of stacking ~130 MB heaps (the intermittent
freeze while loading), a session whose last run left the kernel unsafe refuses
to relaunch and asks for a power cycle, the race heartbeat stops when
execution fails, stage-2 leak failures report their exact reason, and the
success banner tells you to close the browser before shutting down (powering
off with the exploit page in the foreground matches the flashing-white
shutdown hang reported on PS4 Pro). The host also records the console's own
diagnostic posts in .runtime\console-diag.log.

INSTALL
Run GoldHEN-Local-Host-Setup-1.0.7-x64.exe. Choose a writable installation folder
and click Install. Everything is bundled: no Python installation, internet
download, or development tools are needed. It installs for your Windows user
with Start menu shortcuts and an optional desktop shortcut.
The portable ZIP can instead be extracted into a writable folder. Keep its
entire contents together and run Start-Host.cmd; installation is not required.

USE
1. Run Start GoldHEN Host (or Start-Host.cmd).
2. Read the PS4 network address printed in the window. It uses THIS computer's
   current IP, not the original computer's IP. Addresses are also saved in
   .runtime\addresses.txt. Choose the adapter on your PS4's network.
3. Open that exact http://address:8088/g2all/ URL in the PS4 browser.
4. Keep the PC awake. Wait for caching to finish and close/reopen the PS4 browser
   when the page tells you to. A new PC/address may require a fresh cache.
5. Run Stop GoldHEN Host when finished. Closing the launcher window does not
   stop the background server. Restart the host after rebooting the PC.

Version 1.0.1 fixes stopping a host previously started with administrator rights.
If Windows hides that process's details, Stop requests administrator permission
once to stop it. Launch normally afterward; ordinary start/stop needs no elevation.
Repeated Start shows the network address, and repeated Stop reports already stopped.

NETWORK ACCESS
If the PC page works but the console cannot reach it, run Allow PS4 Network
Access. Windows asks for administrator permission. This adds one inbound rule
limited to this executable, the configured TCP port, Private networks, and
devices on the local subnet. Use your trusted home network. No router changes,
port forwarding, Public-network rules, or automatic startup tasks are added.
Remove Network Access removes this installation's rule. Firewall changes are
optional and are not applied silently by installation.

PORT / TROUBLESHOOTING
The default port is 8088. If occupied, stop the other host or edit settings.json
to a free port from 1024 to 65535, restart, and rerun Allow PS4 Network Access if
you used that option. Each PC has its own address. VPN and multiple network
adapters may print additional addresses; choose the PS4's local network.
Check Files validates all 92 assets. Logs are in .runtime. Reinstall if validation
fails. The server serves a verified in-memory snapshot; restart after file edits.

UNINSTALL
If you enabled the optional firewall rule, run Remove Network Access first.
Then uninstall GoldHEN Local Host through Windows Installed apps or Uninstall.cmd.
The uninstaller stops this host and removes only files recorded by the installer.
Custom settings, logs, or other user-created files are retained. The portable
edition can be removed by stopping it and deleting its extracted folder after
removing its firewall rule.

CONTENTS / PROVENANCE
GoldHEN v2.4b18.14 payload (official beta line, replacing the original site
copy v2.4b18.12; source archive GoldHEN_v2.4b18.14.7z) and the same console
scripts as the working host.
Preventive cache/launcher checks, startup integrity verification, Python runtime,
source, source notices and original author credits are included. Third-party
components retain their own terms; see THIRD-PARTY-NOTICES.txt and licenses.
Original public host: https://gamerhack.github.io/g2all/
Upstream commit: 23c946a7f85f1338ea2b78163e72e0ce9bc82b68

The original user reported successful use. This does not guarantee every firmware
or console will behave identically. Console exploit code and native payloads were
not changed for packaging. This locally built installer is not code-signed.
